<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7 my-3">
            <h2>Товар дня</h2>
            <div class="card shadow">
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-3 text-center">
                        <img class="img-fluid" src="<?php echo e(asset($top_day->filename) ? 'images/not_found.jpg' : ''); ?>" alt="<?php echo e($top_day->name); ?>">
                        </div>
                        <div class="col-md-9 top-day">
                            <p class="mb-2"><a href="<?php echo e(url('advert/'.$top_day->slug)); ?>"><?php echo e($top_day->title); ?></a></p>
                            <p class="mb-2">Описание: <?php echo e(Str::limit($top_day->content, 120)); ?></p>
                            <p class="mb-2 float-right">Просмотров: <?php echo e($top_day->views_day); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-5 my-3">
            <h2>Новые объявления</h2>
            <?php $__currentLoopData = $new_adverts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card my-2 shadow">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 text-center">
                                <img class="img-fluid" src="<?php echo e(asset($advert->filename) ? 'images/not_found.jpg' : ''); ?>" alt="">
                            </div>
                            <div class="col-md-8 advert-content">

                                <p class="mb-2"><a href="<?php echo e(url('advert/'.$advert->slug)); ?>"><?php echo e($advert->title); ?></a></p>
                                <p class="mb-2">Описание: <?php echo e(Str::limit($advert->content, 60)); ?></p>
                                <p class="mb-2">Добавлено: <?php echo e($advert->create_date); ?></p>
                                <p class="mb-2"><b>Цена: <?php echo e($advert->types->first()->price ?? ''); ?></b></p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/himiknew.local/resources/views/home.blade.php ENDPATH**/ ?>